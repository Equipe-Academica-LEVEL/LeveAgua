from django.contrib import admin
from .models import app


admin.site.register(app)
